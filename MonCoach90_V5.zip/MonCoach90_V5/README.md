# Mon Coach 90 — V5 (base native Android)

Projet Android natif Kotlin + Jetpack Compose. L'application ne nécessite pas Android Studio pour être compilée :
le workflow GitHub Actions fourni construit automatiquement un APK à chaque push sur `main` ou à la demande.

## Fonctions présentes dans cette base V5
- Tableau de bord quotidien et objectif 90 kg.
- Saisie du poids, de l'hydratation, des pas et de l'humeur.
- Journal alimentaire local.
- Mode anti-fringale avec conseils adaptés au retour du travail.
- Coach motivationnel avec messages.
- Rappels quotidiens prévus à 16 h 30 et 18 h 15.
- Données locales via SharedPreferences.

## Compiler sans Android Studio
1. Créer un dépôt GitHub vide.
2. Envoyer le contenu de ce dossier sur la branche `main`.
3. Ouvrir l'onglet **Actions** du dépôt.
4. Ouvrir **Build Mon Coach 90 APK**.
5. Télécharger l'artefact `MonCoach90-V5-debug` à la fin de l'exécution.
6. Extraire le ZIP : il contient `app-debug.apk`, installable sur Android.

## Important avant mise à jour de V3/V4
Le `applicationId` de cette base est `fr.moncoach90.app`. Pour installer V5 par-dessus V3/V4 sans désinstaller l'ancienne application et conserver ses données, l'identifiant d'application ET le mécanisme de stockage doivent être identiques à ceux de V3/V4.
Les archives V3/V4 n'étant pas présentes dans les fichiers accessibles au moment de la génération, cette compatibilité n'est pas encore certifiée. Ne désinstalle pas V3/V4 avant validation.

## Limites assumées de cette première base V5
- Le nombre de pas est saisi manuellement ; la connexion au capteur de pas/Health Connect reste à intégrer.
- L'analyse de repas par photo et le dialogue IA nécessitent un service IA et une clé/API sécurisée côté serveur ; aucune analyse fictive n'est affichée.
- Les historiques datés et courbes nécessitent une migration de stockage structurée ; ils ne sont pas encore présentés comme opérationnels.
- Les rappels sont des notifications Android simples, avec horaires inexactement répétés par le système pour préserver la batterie.
- Le personnage est représenté par un avatar emoji dans cette base ; les animations illustrées avancées restent à produire.

Cette archive est une base V5 installable après compilation, pas un APK déjà compilé.
